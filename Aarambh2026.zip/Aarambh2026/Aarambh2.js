// Aarambh.js - Canvas orb, particles, interactions, gallery marquee, counters
(function(){
  // Helper for DOM ready
  function ready(fn){ if(document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

  ready(()=>{
    // Mobile menu toggle
    (function mobileMenu(){
      const menuToggle = document.getElementById('menuToggle');
      const navMenu = document.getElementById('navMenu');
      if(!menuToggle || !navMenu) return;
      
      menuToggle.addEventListener('click', ()=>{
        navMenu.classList.toggle('active');
      });
      
      // close menu when a nav link is clicked
      navMenu.querySelectorAll('a').forEach(link=>{
        link.addEventListener('click', ()=> navMenu.classList.remove('active'));
      });
      
      // close menu on resize to desktop
      window.addEventListener('resize', ()=>{
        if(window.innerWidth > 768) navMenu.classList.remove('active');
      });
    })();

    const canvas = document.getElementById('bgCanvas');
    const ctx = canvas.getContext('2d');
    let dpr = Math.max(1, window.devicePixelRatio || 1);
    let w = 0, h = 0;

    function resize(){
      dpr = Math.max(1, window.devicePixelRatio || 1);
      w = window.innerWidth; h = window.innerHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      ctx.setTransform(dpr,0,0,dpr,0,0);
    }
    window.addEventListener('resize', resize);
    resize();

    // particles (simple, small, subtle)
    let particles = [];
    function createParticles(){
      particles = [];
      // fewer, smaller particles for a clean look
      const count = Math.max(30, Math.round((w*h)/250000));
      for(let i=0;i<count;i++){
        const depth = 0.6 + Math.random()*0.6;
        particles.push({
          x: Math.random()*w,
          y: Math.random()*h,
          vx: (Math.random()-0.5) * 0.03 * depth,
          vy: (Math.random()-0.5) * 0.03 * depth,
          baseSize: 0.6 + Math.random()*1.6,
          size: 0.6 + Math.random()*1.6,
          depth: depth,
          alpha: 0.12 + Math.random()*0.36
        });
      }
    }
    createParticles();

    // pointer (limit tracking to hero area to avoid page-wide movement)
    const pointer = {x:w/2,y:h/2,active:false};
    function onMove(x,y){ pointer.x = x; pointer.y = y; pointer.active = true; }
    function onLeave(){ pointer.active=false; }
    // Only track pointer when inside the hero section to prevent subtle page shifts
    const heroSection = document.querySelector('.hero');
    if(heroSection){
      heroSection.addEventListener('mousemove', (e)=> onMove(e.clientX, e.clientY));
      heroSection.addEventListener('touchmove', (e)=>{ const t = e.touches[0]; if(t) onMove(t.clientX,t.clientY); }, {passive:true});
      heroSection.addEventListener('mouseleave', onLeave);
      heroSection.addEventListener('touchend', onLeave);
    } else {
      // fallback: do not attach global pointer handlers to avoid page movement
      window.addEventListener('mouseout', onLeave);
    }

    // Water ripple effect on hover
    (function setupRippleEffect(){
      function createRipple(e){
        const target = e.target.closest('.frost-card, .btn, .hero-logo');
        if(!target) return;
        
        const rect = target.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const ripple = document.createElement('span');
        ripple.className = 'ripple';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        ripple.style.transform = 'translate(-50%, -50%)';
        
        target.appendChild(ripple);
        
        // Remove ripple after animation completes
        setTimeout(() => ripple.remove(), 800);
      }
      
      document.addEventListener('mouseover', createRipple);
    })();

    // Ripples and waves removed: no pointer-driven water effect per user request.

    const title = document.getElementById('titleLarge');
    function updateTitle(){
      if(!title) return;
      const cx = w/2, cy = h/2;
      // only apply rotation while pointer is active (inside hero); otherwise reset transform
      if(!pointer.active){ title.style.transform = ''; return; }
      const rx = (pointer.y - cy) / cy;
      const ry = (pointer.x - cx) / cx;
      const rotX = rx * 4;
      const rotY = ry * -4;
      title.style.transform = `rotateX(${rotX}deg) rotateY(${rotY}deg)`;
    }

    // Scroll-driven logo fade-out
    (function logoScroll(){
      const logo = document.getElementById('heroLogo');
      if(!logo) return;
      const heroSection = document.querySelector('.hero');
      if(!heroSection) return;
      
      function updateLogoOpacity(){
        const heroRect = heroSection.getBoundingClientRect();
        const fadeStart = window.innerHeight * 0.6; // start fading when hero is 60% up
        const fadeEnd = window.innerHeight * 0.1; // fully hidden when hero is 10% up
        
        const progress = Math.max(0, Math.min(1, (fadeStart - heroRect.bottom) / (fadeStart - fadeEnd)));
        logo.style.opacity = 1 - progress;
        
        // add scroll-fade class when fully faded
        if(progress > 0.95) logo.classList.add('scroll-fade');
        else logo.classList.remove('scroll-fade');
      }
      
      window.addEventListener('scroll', updateLogoOpacity, {passive:true});
      updateLogoOpacity(); // init
    })();

    // waves: layered sin waves with ripples and scroll-driven depth
    const waves = {
      layers:[],
      time:0,
      scrollFactor:0
    };
    // initialize 4 layers with increasing depth
    function initWaves(){
      waves.layers = [];
      const baseAmp = Math.max(12, Math.min(60, Math.min(w,h) * 0.02));
      for(let i=0;i<4;i++){
        waves.layers.push({
          speed: 0.12 + i*0.03,
          freq: 0.0035 + i*0.0012,
          amp: baseAmp * (1 + i*0.5),
          phase: Math.random()*Math.PI*2,
          offset: h * (0.55 + i*0.06),
          color: `rgba(212,175,55,${0.06 + i*0.03})`
        });
      }
    }
    initWaves();

    // ripples disabled
    const ripples = [];
    function pushRipple(){ /* no-op: ripples disabled */ }

    // draw
    let last = performance.now();
    function tick(now){ const dt = Math.min(40, now - last)/1000; last = now;
      waves.time += dt;
      // update scroll factor (0..1) based on scrollY relative to viewport height
      const maxScroll = window.innerHeight * 0.8;
      waves.scrollFactor = Math.min(1, window.scrollY / maxScroll);
      // update particles motion with smooth lerp
      for(let p of particles){
        p.x += p.vx * dt * 60;
        p.y += p.vy * dt * 60;
        // wrap
        if(p.x < -10) p.x = w + 10; if(p.x > w + 10) p.x = -10;
        if(p.y < -10) p.y = h + 10; if(p.y > h + 10) p.y = -10;
        // relax size/alpha toward base
        p.size += (p.baseSize - p.size) * 0.06;
        p.alpha += (0.14 - p.alpha) * 0.03;
      }

      // pointer local effect: disabled - no hover bubble
      // if(pointer.active){
      //   const radius = Math.max(80, Math.min(180, Math.hypot(w,h) * 0.08));
      //   const r2 = radius * radius;
      //   for(let p of particles){
      //     const dx = p.x - pointer.x, dy = p.y - pointer.y; const d2 = dx*dx + dy*dy;
      //     if(d2 < r2){
      //       const influence = 1 - (d2 / r2);
      //       p.size = p.size + (p.baseSize * (0.6 * influence));
      //       p.alpha = Math.min(0.9, p.alpha + influence * 0.6 * p.depth);
      //     }
      //   }
      // }

      draw(dt); updateTitle(); requestAnimationFrame(tick);
    }
    function draw(dt){ ctx.clearRect(0,0,w,h);
      ctx.globalCompositeOperation = 'source-over';
      // draw waves behind particles
      drawWaves(ctx, waves, ripples, dt);

      // draw simple small particles (no large orb, no glow)
      for(let p of particles){
        ctx.globalAlpha = Math.max(0, Math.min(1, p.alpha));
        ctx.fillStyle = 'rgba(212,175,55,1)';
        const s = Math.max(0.6, p.size) * (0.9 + p.depth*0.4);
        ctx.beginPath(); ctx.arc(p.x, p.y, s, 0, Math.PI*2); ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    // Wave drawing function
    function drawWaves(ctx, waves, ripples, dt){
      // intentionally left blank — waves disabled per user request
      return;
    }

    // recalc
    function recalc(){ resize(); createParticles(); initWaves(); }
    window.addEventListener('resize', recalc);
    requestAnimationFrame(tick);

    // NAV actions - simple keyboard support
    const focusable = document.querySelectorAll('.btn, a[href]'); focusable.forEach(el=>el.addEventListener('keydown', (e)=>{ if(e.key==='Enter') el.click(); }));

    // Dropdowns (if any) and basic interactions already defined in HTML via buttons

    // --- Gallery marquee animation ---
    // We'll animate rows by translating their content continuously. Rows alternate direction.
    function initGallery(){
      const marquees = document.querySelectorAll('.marquee');
      marquees.forEach((m, idx) => {
        const track = m.querySelector('.marquee-track');
        if(!track) return;
        // speed (px/sec)
        const base = 28; const speed = base + (idx * 10);
        let pos = 0;
        const dir = (idx % 2 === 0) ? -1 : 1; // even -> left (marquee 1,3), odd -> right (marquee 2)
        // Get track width after images load
        function waitForImages(){
          const imgs = track.querySelectorAll('img');
          let loaded = 0;
          if(imgs.length === 0) { startAnimation(); return; }
          imgs.forEach(img => {
            if(img.complete) loaded++;
            else img.addEventListener('load', ()=>{ loaded++; if(loaded === imgs.length) startAnimation(); });
          });
          if(loaded === imgs.length) startAnimation();
        }
        function startAnimation(){
          const trackWidth = track.scrollWidth;
          const halfWidth = trackWidth / 2;
          // initialize position so the duplicated halves loop seamlessly
          pos = (dir === 1) ? -halfWidth : 0;
          function animate(){
            pos += dir * speed * (1/60);
            // Reset position for seamless loop
            if(dir === -1){
              // Moving left: when we've scrolled past half the track, jump back
              if(pos <= -halfWidth) pos = 0;
            } else {
              // Moving right: we start at -halfWidth and move towards 0
              if(pos >= 0) pos = -halfWidth;
            }
            track.style.transform = `translateX(${pos}px)`;
            requestAnimationFrame(animate);
          }
          track.style.willChange = 'transform';
          track.style.transform = `translateX(${pos}px)`;
          requestAnimationFrame(animate);
        }
        waitForImages();
      });
    }
    // Initialize gallery rows on DOM ready and after images loaded
    setTimeout(initGallery, 300);

    // --- Counters when visible ---
    function animateCounter(el, to){ let r=0; const dur=1400; const start=performance.now(); function run(now){ const t=Math.min(1,(now-start)/dur); const eased = (--t)*t*t+1; const val = Math.floor(eased*to); el.textContent = val; if(t<1) requestAnimationFrame(run); else el.textContent = to; } requestAnimationFrame(run); }

    const statEls = document.querySelectorAll('.stat .num');
    if(statEls.length){ const io = new IntersectionObserver((entries,obs)=>{ entries.forEach(e=>{ if(e.isIntersecting){ const el = e.target; const target = parseInt(el.dataset.to || el.textContent) || 0; animateCounter(el, target); obs.unobserve(el); } }); }, {threshold:0.5}); statEls.forEach(el=>io.observe(el)); }

    // --- Simple placeholders population (events, speakers, sponsors) ---
    // For demo, fill events/speakers/sponsors with sample cards if empty
    function populatePlaceholders(){
      const eventsGrid = document.querySelector('.events-grid');
      if(eventsGrid && eventsGrid.children.length===0){ for(let i=1;i<=6;i++){ const c = document.createElement('div'); c.className='event-card'; c.innerHTML = `<strong>Event ${i}</strong><div style="color:var(--muted);margin-top:8px">Quick description of the event ${i}.</div>`; eventsGrid.appendChild(c); } }

      const speakersGrid = document.querySelector('.speakers-grid');
      if(speakersGrid && speakersGrid.children.length===0){ for(let i=1;i<=6;i++){ const s = document.createElement('div'); s.className='speaker'; s.innerHTML = `<img src="https://dummyimage.com/400x300/222/ffd86b&text=S${i}" alt="Speaker ${i}"/><div style="margin-top:8px;font-weight:800">Speaker ${i}</div><div style="color:var(--muted)">Role / Company</div>`; speakersGrid.appendChild(s); } }

      const sponsors = document.querySelector('.sponsors');
      if(sponsors && sponsors.children.length===0){ ['Google AdMob','GitLab','Company X','Company Y'].forEach(n=>{ const sp = document.createElement('div'); sp.className='sponsor'; sp.textContent = n; sponsors.appendChild(sp); }); }
    }
    populatePlaceholders();

    // Remove or hide Spline "Built with Spline" badge if injected by the viewer.
    (function removeSplineBadge(){
      // Try CSS-first: add a style (already in CSS), then aggressively remove nodes containing the text.
      function scanAndRemove(root){
        try{
          // direct search for elements that include the exact text
          const walker = (root || document).querySelectorAll('div,span,a,button');
          walker.forEach(el=>{
            if(!el) return;
            const txt = (el.textContent||'').trim();
            if(txt === 'Built with Spline' || txt === 'Built with spline'){
              el.setAttribute('data-spline-hidden','true');
              if(el.shadowRoot){
                try{ el.shadowRoot.querySelectorAll('*').forEach(s=>s.remove()); }catch(e){}
              }
            }
          });
          // also check inside spline-viewer shadow roots if present
          const viewers = document.querySelectorAll('spline-viewer');
          viewers.forEach(v=>{
            try{
              const sr = v.shadowRoot;
              if(sr){
                const candidates = sr.querySelectorAll('*');
                candidates.forEach(c=>{
                  const t = (c.textContent||'').trim(); if(t==='Built with Spline'){ c.remove(); }
                });
              }
            }catch(e){}
          });
        }catch(e){/*ignore*/}
      }

      // run several times to catch late injection
      let runs = 0; const maxRuns = 40; const id = setInterval(()=>{
        scanAndRemove(document);
        runs++; if(runs>maxRuns) clearInterval(id);
      }, 200);
      // also run once after load
      window.addEventListener('load', ()=> setTimeout(()=>scanAndRemove(document), 150));
    })();

    // Add subtle parallax / float to Spline viewer container
    (function splineParallax(){
      const wrap = document.querySelector('.spline-wrap');
      const embed = document.querySelector('.spline-embed');
      if(!wrap || !embed) return;
      let px = 0, py = 0, rx = 0, ry = 0;
      let targetX = 0, targetY = 0;
      function onMove(e){ const x = (e.touches ? e.touches[0].clientX : e.clientX); const y = (e.touches ? e.touches[0].clientY : e.clientY); const rect = wrap.getBoundingClientRect(); targetX = (x - (rect.left + rect.width/2)) / rect.width * 12; targetY = (y - (rect.top + rect.height/2)) / rect.height * 10; wrap.classList.add('hovered'); }
      function onLeave(){ targetX = 0; targetY = 0; wrap.classList.remove('hovered'); }
      wrap.addEventListener('mousemove', onMove); wrap.addEventListener('touchmove', onMove, {passive:true});
      wrap.addEventListener('mouseleave', onLeave); wrap.addEventListener('touchend', onLeave);

      function animate(){ px += (targetX - px) * 0.08; py += (targetY - py) * 0.08; rx = -py; ry = px; embed.style.transform = `translate3d(${px}px, ${py}px, 0) rotateX(${rx}deg) rotateY(${ry}deg)`; requestAnimationFrame(animate); }
      requestAnimationFrame(animate);
    })();

  }); // ready end
})();

